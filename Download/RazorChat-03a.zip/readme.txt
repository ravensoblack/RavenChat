RazorChat is a remote sysop paging system for Synchronet BBS.
It will also have remote sysop chat in the near future.
The server side currently works on any platform Synchronet works on.
The client side is currently Windows only with .NET 4.6.1, but a Python
version intended for Linux & other Unix-like platforms is coming soon.

Install TLDR:
1. Unzip the archive file
2. Run setup.exe to install the client
3. Copy the files from the JS folder to your BBS /sbbs/mods directory
4. Run jsexec syschatinstall.js
5. Recycle your BBS

Using the client:
Click the gear icon to configure.
Click the plug icon to connect & wait a few seconds.
The colored circle between the Connect & Settings buttons shows the status
of your sysop pager & is also clickable to enable/disable the pager.
When switching between enabled or disabled, wait a few seconds, as the color
only changes when the server has reported back to the client that the pager is enabled.

The client supports the following page types:
Basic: The numbered node on the main pager window flashes.
Visual: The entire pager window & it's taskbar icon will flash.
Audio: The pager comes with 21 audio files to choose from & one of these will be played.
External: The pager allows you to configure a command line to call the notification system of your choice.
The "Info" button to the right of the 2 settings fields for external pages gives more detail of how to set this.

Manual service install on BBS:
After installing the client, you'll want to copy at least the syschatservice.js
file from the JS folder to your mods directory.
Add some form of the following to your services.ini & recycle your BBS:
[SysChat]
Port=10005
MaxClients=5
Command=syschatservice.js

For any issues or for help, please contact razordead@gmail.com or Razor@SILENT via DoveNet
